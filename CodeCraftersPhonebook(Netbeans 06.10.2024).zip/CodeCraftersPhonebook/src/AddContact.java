import java.util.Scanner;

public class AddContact {
    public static void addContact(Phonebook phonebook, Scanner scanner) {
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter phone number: ");
        String phoneNumber = scanner.nextLine();
        phonebook.addContact(new Contact(name, phoneNumber));
        System.out.println("Contact added successfully.");
    }
}