public class SaveContactsToFile {
    public static void saveContactsToFile(Phonebook phonebook) {
        phonebook.saveToFile("contacts.txt");
        System.out.println("Contacts saved to file.");
    }
}