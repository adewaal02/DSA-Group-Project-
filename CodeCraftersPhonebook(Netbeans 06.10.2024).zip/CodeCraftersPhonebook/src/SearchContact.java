import java.util.Scanner;

public class SearchContact {
    public static void searchContact(Phonebook phonebook, Scanner scanner) {
        System.out.print("Enter name to search: ");
        String name = scanner.nextLine();
        Contact contact = phonebook.searchContact(name);
        if (contact != null) {
            System.out.println("Contact found: " + contact);
        } else {
            System.out.println("Contact not found.");
        }
    }
}