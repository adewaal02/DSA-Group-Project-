import java.util.Scanner;

public class UpdateContact {
    public static void updateContact(Phonebook phonebook, Scanner scanner) {
        System.out.print("Enter name to update: ");
        String name = scanner.nextLine();
        System.out.print("Enter new phone number: ");
        String newPhoneNumber = scanner.nextLine();
        if (phonebook.updateContact(name, newPhoneNumber)) {
            System.out.println("Contact updated successfully.");
        } else {
            System.out.println("Contact not found.");
        }
    }
}