package model;

import java.util.ArrayList;
import java.util.List;

public class Contact {
    private final String name;
    private String phoneNumber;
    private List<String> groups;
    private boolean isFavorite;
    private String dob; // Add DOB field

    // Constructor with name and phone number
    public Contact(String name, String phoneNumber) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.groups = new ArrayList<>();
        this.isFavorite = false;
        this.dob = ""; // Initialize dob to an empty string
    }

    // Constructor with name, phone number, and DOB
    public Contact(String name, String phoneNumber, String dob) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.groups = new ArrayList<>();
        this.isFavorite = false;
        this.dob = dob; // Properly initialize dob
    }

    public void setFavorite(boolean favorite) {
        this.isFavorite = favorite;
    }

    public boolean isFavorite() {
        return isFavorite;
    }

    public void addGroup(String group) {
        if (!groups.contains(group)) {
            groups.add(group);
        }
    }

    public List<String> getGroups() {
        return groups;
    }

    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getDob() {
        return dob; // Getter for DOB
    }

    @Override
  public String toString() {
        return name + ": " + phoneNumber + " (DOB: " + dob + ")" + 
               (groups.isEmpty() ? "" : " | Groups: " + String.join(", ", groups));
    }

    // Main method for testing
    public static void main(String[] args) {
        // Creating contacts
        Contact contact1 = new Contact("Alice", "123-456-7890", "1990-01-01");
        Contact contact2 = new Contact("Bob", "987-654-3210", "1985-05-15");
        
        // Adding groups
        contact1.addGroup("Friends");
        contact2.addGroup("Work");

        // Marking one as favorite
        contact1.setFavorite(true);

        // Displaying contact details
        System.out.println(contact1);
        System.out.println(contact2);

        // Testing group functionality
        System.out.println("Groups for " + contact1.getName() + ": " + contact1.getGroups());
        System.out.println("Groups for " + contact2.getName() + ": " + contact2.getGroups());
    }
}
