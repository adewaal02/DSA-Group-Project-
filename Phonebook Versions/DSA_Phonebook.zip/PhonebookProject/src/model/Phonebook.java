package model;

import java.io.*;  // For IOException, BufferedReader, BufferedWriter, FileReader, FileWriter
import java.util.*; // For List, ArrayList, Scanner, Comparator


import java.io.IOException;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Phonebook {
    private List<Contact> contacts = new ArrayList<>();
    private final String filePath = "C:\\Users\\sheld\\OneDrive\\Documents\\NetBeansProjects\\PhonebookProject\\contacts.txt"; // Change to your actual path
    public String getFilePath() {
        return filePath;
    }
    
    public void addContact(Contact contact) {
        contacts.add(contact);
    }

    public List<Contact> getContacts() {
        return contacts;
    }

   public List<Contact> searchContacts(String query) {
    return contacts.stream()
            .filter(contact -> contact.getName().contains(query) || contact.getPhoneNumber().contains(query))
            .collect(Collectors.toList());

    }

    public void deleteContact(String name) {
        contacts.removeIf(contact -> contact.getName().equalsIgnoreCase(name));
    }

    public boolean updateContact(String name, String newPhone) {
        for (Contact contact : contacts) {
            if (contact.getName().equalsIgnoreCase(name)) {
                contact.setPhoneNumber(newPhone); // Make sure Contact has a setter
                return true;
            }
        }
        return false;
    }

    public void saveToFile() throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (Contact contact : contacts) {
                writer.write(contact.getName() + "," + contact.getPhoneNumber());
                writer.newLine();
            }
        }
    }

    public void loadFromFile() throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                addContact(new Contact(parts[0], parts[1]));
            }
        }
    }

    public void sortContacts() {
        contacts.sort(Comparator.comparing(Contact::getName, String.CASE_INSENSITIVE_ORDER));
    }

    public String displayContacts() {
        StringBuilder sb = new StringBuilder();
        for (Contact contact : contacts) {
            sb.append(contact.toString()).append("\n");
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        Phonebook phonebook = new Phonebook();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        // Load contacts from file
        try {
            phonebook.loadFromFile();
        } catch (IOException e) {
            System.out.println("Could not load contacts: " + e.getMessage());
        }

        while (running) {
            System.out.println("Phonebook Menu:");
            System.out.println("1. Add Contact");
            System.out.println("2. Search Contact");
            System.out.println("3. Delete Contact");
            System.out.println("4. Update Contact");
            System.out.println("5. Display Contacts");
            System.out.println("6. Save & Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter phone number: ");
                    String phone = scanner.nextLine();
                    phonebook.addContact(new Contact(name, phone));
                    break;
                case 2:
                    System.out.print("Enter name to search: ");
                    String searchName = scanner.nextLine();
                    Contact foundContact = phonebook.searchContact(searchName);
                    if (foundContact != null) {
                        System.out.println("Found: " + foundContact);
                    } else {
                        System.out.println("Contact not found.");
                    }
                    break;
                case 3:
                    System.out.print("Enter name to delete: ");
                    String deleteName = scanner.nextLine();
                    phonebook.deleteContact(deleteName);
                    System.out.println("Contact deleted if existed.");
                    break;
                case 4:
                    System.out.print("Enter name to update: ");
                    String updateName = scanner.nextLine();
                    System.out.print("Enter new phone number: ");
                    String newPhone = scanner.nextLine();
                    if (phonebook.updateContact(updateName, newPhone)) {
                        System.out.println("Contact updated.");
                    } else {
                        System.out.println("Contact not found.");
                    }
                    break;
                case 5:
                    System.out.println("Contacts:");
                    System.out.println(phonebook.displayContacts());
                    break;
                case 6:
                    // Save contacts to file before exiting
                    try {
                        phonebook.saveToFile();
                        System.out.println("Contacts saved. Exiting.");
                    } catch (IOException e) {
                        System.out.println("Could not save contacts: " + e.getMessage());
                    }
                    running = false;
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }

        scanner.close();
    }

  public boolean contactExists(String name, String phone) {
    for (Contact contact : contacts) {
        if (contact.getName().equalsIgnoreCase(name) || contact.getPhoneNumber().equals(phone)) {
            return true;
        }
    }
    return false;
}

public Contact searchContactByPhone(String phone) {
    for (Contact contact : contacts) {
        if (contact.getPhoneNumber().equals(phone)) {
            return contact;
        }
    }
    return null;
}

    private Contact searchContact(String searchName) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
public Contact findContactByName(String name) {
    for (Contact contact : contacts) { // Assuming contacts is a List<Contact>
        if (contact.getName().equalsIgnoreCase(name)) {
            return contact; // Return the matching contact
        }
    }
    return null; // Return null if no contact is found
}
}