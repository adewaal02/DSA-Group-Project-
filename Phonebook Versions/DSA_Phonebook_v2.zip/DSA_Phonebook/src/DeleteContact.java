import java.util.Scanner;

public class DeleteContact {
    public static void deleteContact(Phonebook phonebook, Scanner scanner) {
        System.out.print("Enter name to delete: ");
        String name = scanner.nextLine();
        if (phonebook.deleteContact(name)) {
            System.out.println("Contact deleted successfully.");
        } else {
            System.out.println("Contact not found.");
        }
    }
}