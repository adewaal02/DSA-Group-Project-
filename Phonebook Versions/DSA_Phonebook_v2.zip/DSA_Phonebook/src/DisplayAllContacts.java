public class DisplayAllContacts {
    public static void displayAllContacts(Phonebook phonebook) {
        phonebook.displayAllContacts();
    }
}