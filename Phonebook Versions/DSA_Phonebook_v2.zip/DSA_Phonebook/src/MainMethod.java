import java.util.Scanner;

public class MainMethod {
    private static Scanner scanner = new Scanner(System.in);
    private static Phonebook phonebook = new Phonebook();

    public static void main(String[] args) {
        displayMenu();
        while (true) {
            int choice = getUserChoice();
            handleUserChoice(choice);
        }
    }

    private static void displayMenu() {
        System.out.println("1. Add Contact");
        System.out.println("2. Search Contact");
        System.out.println("3. Display All Contacts");
        System.out.println("4. Delete Contact");
        System.out.println("5. Update Contact");
        System.out.println("6. Sort Contacts");
        System.out.println("7. Save Contacts to File");
        System.out.println("8. Exit");
        System.out.print("Enter your choice: ");
    }

    private static int getUserChoice() {
        int choice = 0;
        try {
            choice = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number.");
        }
        return choice;
    }

    private static void handleUserChoice(int choice) {
        switch (choice) {
            case 1: AddContact.addContact(phonebook, scanner); break;
            case 2: SearchContact.searchContact(phonebook, scanner); break;
            case 3: DisplayAllContacts.displayAllContacts(phonebook); break;
            case 4: DeleteContact.deleteContact(phonebook, scanner); break;
            case 5: UpdateContact.updateContact(phonebook, scanner); break;
            case 6: SortContacts.sortContacts(phonebook); break;
            case 7: SaveContactsToFile.saveContactsToFile(phonebook); break;
            case 8: System.exit(0);
            default: System.out.println("Invalid choice. Please try again.");
        }
    }

    public static void handleGUIInput(String input) {
        try {
            int choice = Integer.parseInt(input);
            handleUserChoice(choice);
        } catch (NumberFormatException e) {
            System.out.println("Invalid input from GUI. Please enter a number.");
        }
    }
}