import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.sound.sampled.*;

public class PhoneGUI extends JFrame {
    public PhoneGUI() {
        setTitle("Handheld Phone Device");
        setSize(400, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create the display panel
        JPanel displayPanel = new JPanel();
        displayPanel.setPreferredSize(new Dimension(400, 200));
        displayPanel.setBackground(Color.BLACK);
        add(displayPanel, BorderLayout.NORTH);

        // Create the keypad panel
        JPanel keypadPanel = createKeypadPanel();
        // Create the QWERTY panel
        JPanel qwertyPanel = createQwertyPanel();

        // Combine the numpad and QWERTY panels
        JPanel combinedPanel = new JPanel();
        combinedPanel.setLayout(new BorderLayout());
        combinedPanel.add(keypadPanel, BorderLayout.NORTH);
        combinedPanel.add(qwertyPanel, BorderLayout.CENTER);

        add(combinedPanel, BorderLayout.CENTER);
    }

    private JPanel createKeypadPanel() {
        JPanel keypadPanel = new JPanel();
        keypadPanel.setLayout(new GridLayout(5, 3));
        String[] numpadLabels = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#"};
        for (String label : numpadLabels) {
            JButton button = new JButton(label);
            button.addActionListener(new ButtonClickListener());
            keypadPanel.add(button);
        }
        return keypadPanel;
    }

    private JPanel createQwertyPanel() {
        JPanel qwertyPanel = new JPanel();
        qwertyPanel.setLayout(new GridLayout(4, 10));
        String[] qwertyLabels = {
                "Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P",
                "A", "S", "D", "F", "G", "H", "J", "K", "L",
                "Z", "X", "C", "V", "B", "N", "M", " ", " ", " "
        };
        for (String label : qwertyLabels) {
            JButton button = new JButton(label);
            button.addActionListener(new ButtonClickListener());
            qwertyPanel.add(button);
        }
        return qwertyPanel;
    }

    private class ButtonClickListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JButton source = (JButton) e.getSource();
            playSound(source.getText());
            MainMethod.handleGUIInput(source.getText());
        }
    }

    private void playSound(String buttonLabel) {
        try {
            // Assuming you have sound files named "1.wav", "2.wav", etc.
            String soundFile = buttonLabel + ".wav";
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(getClass().getResource(soundFile));
            Clip clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.start();
        } catch (Exception ex) {
            System.out.println("Error playing sound: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            PhoneGUI phoneGUI = new PhoneGUI();
            phoneGUI.setVisible(true);
        });
    }
}