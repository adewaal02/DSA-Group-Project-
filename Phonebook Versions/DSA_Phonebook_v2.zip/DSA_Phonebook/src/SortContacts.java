public class SortContacts {
    public static void sortContacts(Phonebook phonebook) {
        phonebook.sortContacts();
        System.out.println("Contacts sorted.");
    }
}