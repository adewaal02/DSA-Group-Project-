package javaapplication9;

import view.WelcomePage1;

public class JavaApplication9 {

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new WelcomePage1().setVisible(true);
            }
        });
    }
}
