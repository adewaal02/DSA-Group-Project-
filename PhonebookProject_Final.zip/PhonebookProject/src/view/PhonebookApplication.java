package view;

import model.Contact;
import model.Phonebook;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class PhonebookApplication extends javax.swing.JFrame {
    private Phonebook phonebook = new Phonebook();
    private DefaultTableModel tableModel;

    public PhonebookApplication() {
        initComponents();
        // Initialize the table model
        tableModel = new DefaultTableModel(new Object[]{"Name", "Phone", "Gender", "DOB", "Address"}, 0);
        jTable1.setModel(tableModel); 
        loadContacts(); // Load contacts after initializing the table model
        
        // Set tooltip for DOB field
        jTextField3.setToolTipText("Enter DOB in format: DD-Mon-YYYY (e.g., 28-May-2006)");
    }

    private void clearFields() {
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
        jComboBox1.setSelectedIndex(0);
    }

   
private void saveContactToFile(Contact contact) {
        try (FileWriter writer = new FileWriter(phonebook.getFilePath(), true)) {
            writer.write(contact.getName() + "," + contact.getPhoneNumber() + "," +
                    contact.getDob() + "," + contact.getAddress() + "," + contact.getGender() + "\n");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving contact: " + e.getMessage());
        }
    }

    private void loadContacts() {
        try {
            File file = new File(phonebook.getFilePath());
            if (!file.exists()) {
                file.createNewFile();
            }
            phonebook.loadFromFile();
            displayContactsInTable();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading contacts: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void displayContactsInTable() {
         tableModel.setRowCount(0); // Clear existing rows
        for (Contact contact : phonebook.getContacts()) {
            tableModel.addRow(new Object[]{
                contact.getName(),
                contact.getPhoneNumber(),
                contact.getGender(),  
                contact.getDob(),     
                contact.getAddress()  
            });
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1001, 644));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Phone Number");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, -1, 26));

        jLabel1.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Name");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 100, -1));

        jTextField1.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 20, 352, 40));

        jTextField2.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        getContentPane().add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 80, 352, 40));

        jButton1.setBackground(new java.awt.Color(153, 0, 0));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Add Contact");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 230, 190, -1));

        jButton2.setBackground(new java.awt.Color(153, 0, 0));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Display Contact");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 230, 190, -1));

        jButton3.setBackground(new java.awt.Color(153, 0, 0));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Search Contact");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 370, 190, -1));

        jButton4.setBackground(new java.awt.Color(153, 0, 0));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Delete Contact");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 440, 190, -1));

        jButton5.setBackground(new java.awt.Color(153, 0, 0));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("Update Contact");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 300, 190, -1));

        jButton6.setBackground(new java.awt.Color(153, 0, 0));
        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("Sort Contacts ");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 370, 190, -1));

        jButton7.setBackground(new java.awt.Color(153, 0, 0));
        jButton7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("Save Contacts");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 300, 190, -1));

        jButton8.setBackground(new java.awt.Color(153, 0, 0));
        jButton8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setText("EXIT");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1188, 10, -1, -1));

        jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        jLabel4.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Date Of Birth");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 130, -1));

        jTextField3.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        getContentPane().add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 140, 352, 40));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name(s)", "Phone Number", "Gender", "D.O.B", "Address"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(545, 185, 566, 409));

        jLabel3.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Address");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 20, 75, -1));

        jComboBox1.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male ", "Female", " ", " " }));
        getContentPane().add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 90, 352, 40));

        jLabel5.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Gender");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 80, 75, -1));

        jTextField4.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        getContentPane().add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 20, 352, 40));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Image1.jpg"))); // NOI18N
        jLabel6.setText("jLabel6");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 640));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to exit the application?",
            "Exit Application",
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            System.exit(0); // This will close the entire application
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
  String name = jTextField1.getText();
        String phone = jTextField2.getText();
        String dob = jTextField3.getText(); // Get DOB
        String address = jTextField4.getText();
        String gender = (String) jComboBox1.getSelectedItem();

        if (name.isEmpty() || phone.isEmpty() || dob.isEmpty() || address.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter all fields.");
            return;
        }
        
        if (!isValidDateFormat(dob)) {
            JOptionPane.showMessageDialog(this, "Invalid DOB format. Please use DD-Mon-YYYY (e.g., 27-Nov-1988)");
            return;
        }

        if (phonebook.contactExists(name, phone)) {
            JOptionPane.showMessageDialog(this, "Contact already exists.");
            return;
        }

        Contact newContact = new Contact(name, phone, dob, address, gender); // Include all fields
        phonebook.addContact(newContact);
        saveContactToFile(newContact);
        JOptionPane.showMessageDialog(this, "Contact added: " + name + " - " + phone + " (DOB: " + dob + ")");
        clearFields();
        displayContactsInTable();

    }//GEN-LAST:event_jButton1ActionPerformed
 private boolean isValidDateFormat(String date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
        sdf.setLenient(false);
        try {
            sdf.parse(date);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
          displayContactsInTable();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
         String[] options = {"Search by Name", "Search by Phone Number"};
        int choice = JOptionPane.showOptionDialog(this, "Choose search method:", "Search Contact",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

        String searchTerm = JOptionPane.showInputDialog(this, "Enter search term:");
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return;
        }   
        
        Contact foundContact = null;
        if (choice == 0) { // Search by Name
            foundContact = phonebook.findContactByName(searchTerm);
        } else if (choice == 1) { // Search by Phone Number
            foundContact = phonebook.searchContactByPhone(searchTerm);
        }

        if (foundContact != null) {
            highlightContactInTable(foundContact);
            JOptionPane.showMessageDialog(this, "Contact found: " + foundContact);
        } else {
            JOptionPane.showMessageDialog(this, "Contact not found.");
        }
    }

    private void highlightContactInTable(Contact contact) {
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if (tableModel.getValueAt(i, 0).equals(contact.getName()) &&
                tableModel.getValueAt(i, 1).equals(contact.getPhoneNumber())) {
                jTable1.setRowSelectionInterval(i, i);
                jTable1.scrollRectToVisible(jTable1.getCellRect(i, 0, true));
                break;
            }
        }

        // Set custom cell renderer for highlighting
        jTable1.setDefaultRenderer(Object.class, new TableCellRenderer() {
            private final TableCellRenderer defaultRenderer = jTable1.getDefaultRenderer(Object.class);

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = defaultRenderer.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (isSelected) {
                    c.setBackground(Color.BLUE);
                    c.setForeground(Color.WHITE);
                } else {
                    c.setBackground(table.getBackground());
                    c.setForeground(table.getForeground());
                }
                return c;
            }
        });
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
    String[] options = {"Delete by Name", "Delete by Phone Number"};
        int choice = JOptionPane.showOptionDialog(this, "Choose delete method:", "Delete Contact",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

        String searchTerm = JOptionPane.showInputDialog(this, "Enter " + (choice == 0 ? "name" : "phone number") + " to delete:");
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return;
        }
        Contact contactToDelete = null;
        if (choice == 0) { // Delete by Name
            contactToDelete = phonebook.findContactByName(searchTerm);
        } else { // Delete by Phone Number
            contactToDelete = phonebook.searchContactByPhone(searchTerm);
        }

        if (contactToDelete == null) {
            JOptionPane.showMessageDialog(this, "Contact not found.", "Delete Contact", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int confirmDelete = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete this contact?\n" + contactToDelete,
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);

        if (confirmDelete == JOptionPane.YES_OPTION) {
            phonebook.deleteContact(contactToDelete.getName());
            try {
                phonebook.saveToFile();
                displayContactsInTable();
                JOptionPane.showMessageDialog(this, "Contact deleted successfully.", "Delete Contact", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error saving after deleting contact: " + e.getMessage(), "Delete Contact", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        String name = jTextField1.getText();
        String phone = jTextField2.getText();
        String dob = jTextField3.getText();
        String address = jTextField4.getText();
        String gender = (String) jComboBox1.getSelectedItem();

        if (name.isEmpty() || phone.isEmpty() || dob.isEmpty() || address.isEmpty() || gender.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter all fields to perform update", "Update Contact", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (!isValidDateFormat(dob)) {
            JOptionPane.showMessageDialog(this, "Invalid DOB format. Please use DD-Mon-YYYY (e.g., 27-Nov-1988)", "Update Contact", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        Contact existingContact = phonebook.findContactByName(name);
        if (existingContact == null) {
            JOptionPane.showMessageDialog(this, "Contact not found: " + name, "Update Contact", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        existingContact.setPhoneNumber(phone);
        existingContact.setDob(dob);
        existingContact.setAddress(address);
        existingContact.setGender(gender);
        
        try {
            phonebook.saveToFile();
            displayContactsInTable();
            JOptionPane.showMessageDialog(this, "Contact updated successfully: " + name, "Update Contact", JOptionPane.INFORMATION_MESSAGE);
            clearFields();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving updated contact: " + e.getMessage(), "Update Contact", JOptionPane.ERROR_MESSAGE);
        }
        
         String newPhone = jTextField2.getText();
            String newGender = (String) jComboBox1.getSelectedItem();
            String newDOB = jTextField3.getText();
            String newAddress = jTextField4.getText();

            if (phonebook.updateContact(name, newPhone)) {
                int rowIndex = getContactRowIndex(name);
            if (rowIndex != -1) {
                tableModel.setValueAt(newPhone, rowIndex, 1);
                tableModel.setValueAt(newGender, rowIndex, 2);
                tableModel.setValueAt(newDOB, rowIndex, 3);
                tableModel.setValueAt(newAddress, rowIndex, 4);
            JOptionPane.showMessageDialog(this, "Contact updated: " + name);
            }
        } 
            
            else {
                JOptionPane.showMessageDialog(this, "Contact not found: " + name);
}
        clearFields();

    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
 phonebook.sortContacts();
        displayContactsInTable();
        JOptionPane.showMessageDialog(this, "Contacts sorted.");
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
   try {
            phonebook.saveToFile();
            JOptionPane.showMessageDialog(this, "Contacts saved.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving contacts: " + ex.getMessage());
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    // End of variables declaration//GEN-END:variables

private int getContactRowIndex(String name) {
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if (tableModel.getValueAt(i, 0).equals(name)) {
                return i;
            }
        }
        return -1;
    }

}