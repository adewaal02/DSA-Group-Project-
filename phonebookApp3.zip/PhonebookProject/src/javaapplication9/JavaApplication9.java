package javaapplication9;

import view.PhonebookApplication;

public class JavaApplication9 {

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PhonebookApplication().setVisible(true);
            }
        });
    }
}
